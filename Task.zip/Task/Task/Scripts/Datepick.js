﻿$(document).ready(function () {
    // create DatePicker from input HTML element

    $("#Domestic_Admission_Deadline").kendoDatePicker({
        // defines the start view
        start: "year",

        // defines when the calendar should return date
        depth: "year",

        // display month and year in the input
        format: "dd-MMM"
    });

});

$(document).ready(function () {
    // create DatePicker from input HTML element

    $("#International_Admission_Deadline").kendoDatePicker({
        // defines the start view
        start: "year",

        // defines when the calendar should return date
        depth: "year",

        // display month and year in the input
        format: "dd-MMM"
    });

});


$(document).ready(function () {
    // create DatePicker from input HTML element

    $("#Domestic_Admission_Notification").kendoDatePicker({
        // defines the start view
        start: "year",

        // defines when the calendar should return date
        depth: "year",

        // display month and year in the input
        format: "dd-MMM"
    });

});

$(document).ready(function () {
    // create DatePicker from input HTML element

    $("#International_Admission_Notification").kendoDatePicker({
        // defines the start view
        start: "year",

        // defines when the calendar should return date
        depth: "year",

        // display month and year in the input
        format: "dd-MMM"
    });

});
  